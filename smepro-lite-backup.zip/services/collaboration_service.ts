




import { GoogleGenAI } from '@google/genai';
import { ChatSession, Message, SmeConfig, UserProfile, SubscriptionPlan, TypingUser } from '../types';

const SESSIONS_DB_KEY = 'smeProCollaborativeSessions_DB';
const LATENCY = 20; // Use low latency for real-time simulation

type SessionListener = (session: ChatSession) => void;
type TypingListener = (users: TypingUser[]) => void;

class CollaborationService {
    private sessions: Map<string, ChatSession> = new Map();
    private sessionListeners: Map<string, Set<SessionListener>> = new Map();
    private typingStatus: Map<string, TypingUser[]> = new Map();
    private typingListeners: Map<string, Set<TypingListener>> = new Map();
    private typingTimeouts: Map<string, number> = new Map();

    constructor() {
        this.loadSessionsFromStorage();
    }

    private async loadSessionsFromStorage() {
        try {
            const data = localStorage.getItem(SESSIONS_DB_KEY);
            if (data) {
                const storedSessions: Record<string, ChatSession> = JSON.parse(data);
                for (const sessionId in storedSessions) {
                    this.sessions.set(sessionId, storedSessions[sessionId]);
                }
            }
        } catch (e) {
            console.error("Failed to load sessions from local storage", e);
        }
    }

    private async persistSession(sessionId: string) {
        await new Promise(res => setTimeout(res, LATENCY));
        const session = this.sessions.get(sessionId);
        if (session) {
            const allSessions = Object.fromEntries(this.sessions.entries());
            localStorage.setItem(SESSIONS_DB_KEY, JSON.stringify(allSessions));
        }
    }

    private broadcastSessionUpdate(sessionId: string) {
        const session = this.sessions.get(sessionId);
        if (session) {
            this.sessionListeners.get(sessionId)?.forEach(listener => listener(JSON.parse(JSON.stringify(session))));
            this.persistSession(sessionId);
        }
    }
    
    private broadcastTypingUpdate(sessionId: string) {
        const users = this.typingStatus.get(sessionId) || [];
        this.typingListeners.get(sessionId)?.forEach(listener => listener([...users]));
    }

    // --- Public API ---

    async getSession(sessionId: string, smeConfig?: SmeConfig, plan?: SubscriptionPlan): Promise<ChatSession | null> {
        await new Promise(res => setTimeout(res, LATENCY));
        if (this.sessions.has(sessionId)) {
            return this.sessions.get(sessionId)!;
        }
        if (smeConfig && plan) {
            const newSession: ChatSession = {
                sessionId,
                plan,
                smeConfigs: [smeConfig],
                messages: [{
                    role: 'model',
                    parts: [{ text: `Hello! I am your SME for **${smeConfig.segment}** within **${smeConfig.subType}**. Here to deliver clarity and actionable outcomes.` }]
                }],
                participants: [],
                lastModified: Date.now(),
                status: 'active',
            };
            this.sessions.set(sessionId, newSession);
            this.persistSession(sessionId);
            return newSession;
        }
        return null;
    }

    async getAllSessions(): Promise<ChatSession[]> {
        await new Promise(res => setTimeout(res, LATENCY));
        const allSessions: ChatSession[] = [];
        try {
            const data = localStorage.getItem(SESSIONS_DB_KEY);
            if (data) {
                const storedSessions: Record<string, ChatSession> = JSON.parse(data);
                for (const sessionId in storedSessions) {
                    allSessions.push(storedSessions[sessionId]);
                }
            }
        } catch (e) {
            console.error("Failed to load all sessions from local storage", e);
        }
        return allSessions.sort((a, b) => b.lastModified - a.lastModified);
    }

    // FIX: Added missing deleteSession method
    async deleteSession(sessionId: string): Promise<void> {
        await new Promise(res => setTimeout(res, LATENCY));
        if (this.sessions.has(sessionId)) {
            this.sessions.delete(sessionId);
            this.sessionListeners.delete(sessionId);
            this.typingStatus.delete(sessionId);
            this.typingListeners.delete(sessionId);
            const allSessions = Object.fromEntries(this.sessions.entries());
            localStorage.setItem(SESSIONS_DB_KEY, JSON.stringify(allSessions));
        }
    }

    async joinSession(sessionId: string, user: UserProfile) {
        await new Promise(res => setTimeout(res, LATENCY));
        const session = this.sessions.get(sessionId);
        if (session && !session.participants.some(p => p.email === user.email)) {
            session.participants.push(user);
            this.broadcastSessionUpdate(sessionId);
        }
    }

    async leaveSession(sessionId: string, user: UserProfile) {
        await new Promise(res => setTimeout(res, LATENCY));
        const session = this.sessions.get(sessionId);
        if (session) {
            session.participants = session.participants.filter(p => p.email !== user.email);
            this.broadcastSessionUpdate(sessionId);
        }
    }
    
    async sendMessage(sessionId: string, message: Message) {
        await new Promise(res => setTimeout(res, LATENCY));
        const session = this.sessions.get(sessionId);
        if (session) {
            session.messages.push(message);
            session.lastModified = Date.now();
            this.broadcastSessionUpdate(sessionId);
        }
    }
    
    async replaceLastMessage(sessionId: string, message: Message) {
        await new Promise(res => setTimeout(res, LATENCY));
        const session = this.sessions.get(sessionId);
        if (session && session.messages.length > 0) {
            session.messages[session.messages.length - 1] = message;
            session.lastModified = Date.now();
            this.broadcastSessionUpdate(sessionId);
        }
    }
    
    async updateStreamingMessage(sessionId: string, textChunk: string) {
        const session = this.sessions.get(sessionId);
        if (session && session.messages.length > 0) {
            const lastMessage = session.messages[session.messages.length - 1];
            if (lastMessage.role === 'model') {
                lastMessage.parts = [{ text: textChunk }];
                this.broadcastSessionUpdate(sessionId);
            }
        }
    }

    async updateSessionTitle(sessionId: string, title?: string) {
        await new Promise(res => setTimeout(res, LATENCY));
        const session = this.sessions.get(sessionId);
        if (session) {
            session.title = title;
            session.lastModified = Date.now();
            this.broadcastSessionUpdate(sessionId);
        }
    }

    async saveSession(sessionId: string) {
        await this.persistSession(sessionId);
    }

    async addSmeToSession(sessionId: string, smeConfig: SmeConfig, currentMessages: Message[]) {
        const session = this.sessions.get(sessionId);
        if (!session || session.smeConfigs.some(c => c.segment === smeConfig.segment && c.subType === smeConfig.subType)) {
            return; // Exit if session doesn't exist or SME is already present
        }

        // 1. Update session state
        session.smeConfigs.push(smeConfig);
        session.lastModified = Date.now();
        this.broadcastSessionUpdate(sessionId);

        // 2. Add a placeholder message for the new SME's introduction
        const placeholderMessage: Message = { role: 'model', parts: [{ text: '' }] };
        await this.sendMessage(sessionId, placeholderMessage);

        // 3. Generate the contextual introduction using Gemini API
        try {
            if (!process.env.API_KEY) throw new Error("API_KEY not set for collaboration service.");
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

            const history = currentMessages
                .slice(-4) // Take the last 4 messages for context
                .map(msg => `[${msg.role}]: ${msg.parts.map(p => p.text).join('\n')}`)
                .join('\n');

            const systemInstruction = {
                text: `You are an AI expert specializing in ${smeConfig.segment} (${smeConfig.subType}, ${smeConfig.industry}). You have just been added to an ongoing conversation to provide your specific expertise. The last few messages are provided below for context.
                
                Chat History Context:
                ${history}

                Your task is to write a brief, one-paragraph introduction. Acknowledge the ongoing topic based on the history and state how you can contribute. Be natural and helpful.`
            };

            const responseStream = await ai.models.generateContentStream({
                model: 'gemini-2.5-flash',
                contents: [{ role: 'user', parts: [systemInstruction] }],
            });

            let fullResponseText = '';
            for await (const chunk of responseStream) {
                fullResponseText += chunk.text;
                await this.updateStreamingMessage(sessionId, fullResponseText);
            }

            const finalMessage: Message = { role: 'model', parts: [{ text: fullResponseText }] };
            await this.replaceLastMessage(sessionId, finalMessage);

        } catch (e) {
            console.error("Failed to generate SME intro:", e);
            const errorMessage = e instanceof Error ? e.message : "An unknown error occurred.";
            const fallbackMessage: Message = {
                role: 'model',
                parts: [{ text: `Hello! An expert in **${smeConfig.segment}** has joined, but encountered an issue while introducing themselves: ${errorMessage}` }]
            };
            await this.replaceLastMessage(sessionId, fallbackMessage);
        }
    }

    async updateMessageFeedback(sessionId: string, messageIndex: number, vote: 'up'|'down', text: string) {
        await new Promise(res => setTimeout(res, LATENCY));
        const session = this.sessions.get(sessionId);
        if(session && session.messages[messageIndex]) {
            session.messages[messageIndex].feedback = { vote, text };
            this.broadcastSessionUpdate(sessionId);
        }
    }
    
    async updateGuidedSessionStep(sessionId: string, messageIndex: number, stepIndex: number, action: 'select' | 'complete') {
        await new Promise(res => setTimeout(res, LATENCY));
        const session = this.sessions.get(sessionId);
        const message = session?.messages[messageIndex];
        if (message && message.guidedSessionData) {
            const steps = message.guidedSessionData.steps;

            if (action === 'select') {
                // A step can be selected to become active, regardless of its current state.
                // This is how a user "re-opens" a completed step.
                const wasPreviouslyComplete = steps[stepIndex]?.status === 'complete';

                steps.forEach((step, idx) => {
                    // Set the selected step to active
                    if (idx === stepIndex) {
                        step.status = 'active';
                    } 
                    // If another step was active, set it to pending
                    else if (step.status === 'active') {
                        step.status = 'pending';
                    }
                    
                    // If a completed step was selected, we need to reset the progress
                    // of all subsequent steps. This fulfills the requirement to mark
                    // later steps as 'pending'.
                    if (wasPreviouslyComplete && idx > stepIndex) {
                        step.status = 'pending';
                    }
                });

            } else if (action === 'complete') {
                const stepToComplete = steps[stepIndex];
                // Only an active step can be marked as complete.
                if (stepToComplete && stepToComplete.status === 'active') {
                    stepToComplete.status = 'complete';

                    // For a smoother user experience, automatically activate the next pending step.
                    const nextStep = steps.find((step, idx) => idx > stepIndex && step.status === 'pending');
                    if (nextStep) {
                        nextStep.status = 'active';
                    }
                }
            }
            this.broadcastSessionUpdate(sessionId);
        }
    }
    
    async updateTypingStatus(sessionId: string, user: UserProfile, isTyping: boolean) {
        const typingKey = `${sessionId}-${user.email}`;
        
        // Clear any existing timeout for this user
        if (this.typingTimeouts.has(typingKey)) {
            clearTimeout(this.typingTimeouts.get(typingKey));
            this.typingTimeouts.delete(typingKey);
        }

        let users = this.typingStatus.get(sessionId) || [];
        const userIsCurrentlyTyping = users.some(u => u.userId === user.email);

        if (isTyping) {
            if (!userIsCurrentlyTyping) {
                users.push({ userId: user.email, userName: user.name });
                this.typingStatus.set(sessionId, users);
                this.broadcastTypingUpdate(sessionId);
            }
            // Set a timeout to automatically remove the user after a delay
            const timeoutId = window.setTimeout(() => {
                this.updateTypingStatus(sessionId, user, false);
            }, 3000); // User is considered not typing after 3 seconds of inactivity
            this.typingTimeouts.set(typingKey, timeoutId);
        } else {
            if (userIsCurrentlyTyping) {
                users = users.filter(u => u.userId !== user.email);
                this.typingStatus.set(sessionId, users);
                this.broadcastTypingUpdate(sessionId);
            }
        }
    }

    async updateSessionStatus(sessionId: string, status: 'active' | 'archived'): Promise<void> {
        await new Promise(res => setTimeout(res, LATENCY));
        const session = this.sessions.get(sessionId);
        if (session) {
            session.status = status;
            this.broadcastSessionUpdate(sessionId);
        }
    }

    async batchUpdateSessionStatus(updates: Array<{ sessionId: string; status: 'active' | 'archived' }>): Promise<void> {
        await new Promise(res => setTimeout(res, LATENCY));
        let changed = false;
        for (const update of updates) {
            const session = this.sessions.get(update.sessionId);
            if (session && session.status !== update.status) {
                session.status = update.status;
                changed = true;
            }
        }
        if (changed) {
            const allSessions = Object.fromEntries(this.sessions.entries());
            localStorage.setItem(SESSIONS_DB_KEY, JSON.stringify(allSessions));
        }
    }


    subscribe(sessionId: string, listener: SessionListener) {
        if (!this.sessionListeners.has(sessionId)) {
            this.sessionListeners.set(sessionId, new Set());
        }
        this.sessionListeners.get(sessionId)!.add(listener);
    }

    unsubscribe(sessionId: string, listener: SessionListener) {
        this.sessionListeners.get(sessionId)?.delete(listener);
    }
    
    subscribeToTyping(sessionId: string, listener: TypingListener) {
        if (!this.typingListeners.has(sessionId)) {
            this.typingListeners.set(sessionId, new Set());
        }
        this.typingListeners.get(sessionId)!.add(listener);
    }
    
    unsubscribeFromTyping(sessionId: string, listener: TypingListener) {
        this.typingListeners.get(sessionId)?.delete(listener);
    }
}

export const collaborationService = new CollaborationService();