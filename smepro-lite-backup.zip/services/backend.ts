import { VaultItem, FlaggedPrompt, UserProfile } from '../types';

// --- LocalStorage Mock Backend ---
// This mock service replaces the live API calls to prevent "Failed to fetch" errors
// when the backend is unavailable. It uses localStorage to persist data.

const VAULT_ITEMS_KEY = 'smePro_vaultItems';
const VAULT_CATEGORIES_KEY = 'smePro_vaultCategories';
const SAFETY_KEYWORDS_KEY = 'smePro_safetyKeywords';
const FLAGGED_PROMPTS_KEY = 'smePro_flaggedPrompts';
const USER_PROFILE_KEY = 'smePro_userProfile';
const SIMULATED_LATENCY = 150;

// Helper function to simulate network delay
const simulateApiCall = <T>(data: T): Promise<T> => {
    return new Promise(resolve => {
        // Deep copy to prevent object reference issues
        setTimeout(() => resolve(JSON.parse(JSON.stringify(data))), SIMULATED_LATENCY);
    });
};

const getFromStorage = <T>(key: string, defaultValue: T): T => {
    try {
        const storedValue = localStorage.getItem(key);
        return storedValue ? JSON.parse(storedValue) : defaultValue;
    } catch (error) {
        console.error(`Error reading from localStorage key "${key}":`, error);
        return defaultValue;
    }
};

const saveToStorage = (key: string, data: any) => {
    try {
        localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
        console.error(`Error writing to localStorage key "${key}":`, error);
    }
};

const DEFAULT_CATEGORIES = [
    "Strategic Plans",
    "Action Items",
    "Research & Data",
    "Creative Ideas",
    "Generated Definitions",
    "Key Contacts",
    "Procedural Guides",
    "Meeting Notes",
    "Uncategorized"
];

const DEFAULT_KEYWORDS = ["finance", "confidential", "password", "proprietary", "trade secret"];

export const backend = {
  async fetchVaultItems(): Promise<VaultItem[]> {
    const items = getFromStorage<VaultItem[]>(VAULT_ITEMS_KEY, []);
    return simulateApiCall(items);
  },

  async saveVaultItems(itemsToSave: VaultItem[]): Promise<VaultItem[]> {
    const existingItems = getFromStorage<VaultItem[]>(VAULT_ITEMS_KEY, []);
    // Avoid duplicates by checking IDs
    const newItems = itemsToSave.filter(newItem => !existingItems.some(existing => existing.id === newItem.id));
    const updatedItems = [...existingItems, ...newItems];
    saveToStorage(VAULT_ITEMS_KEY, updatedItems);
    return simulateApiCall(itemsToSave);
  },

  async saveVaultItem(item: VaultItem): Promise<VaultItem> {
    let items = getFromStorage<VaultItem[]>(VAULT_ITEMS_KEY, []);
    const itemIndex = items.findIndex(i => i.id === item.id);
    if (itemIndex > -1) {
        items[itemIndex] = item;
    } else {
        items.push(item);
    }
    saveToStorage(VAULT_ITEMS_KEY, items);
    return simulateApiCall(item);
  },

  async deleteVaultItem(itemId: string): Promise<void> {
    let items = getFromStorage<VaultItem[]>(VAULT_ITEMS_KEY, []);
    items = items.filter(i => i.id !== itemId);
    saveToStorage(VAULT_ITEMS_KEY, items);
    return simulateApiCall(undefined as void);
  },
  
  async deleteVaultItemsByOrigin(origin: string): Promise<void> {
    let items = getFromStorage<VaultItem[]>(VAULT_ITEMS_KEY, []);
    items = items.filter(i => i.origin !== origin);
    saveToStorage(VAULT_ITEMS_KEY, items);
    return simulateApiCall(undefined as void);
  },

  // --- Categories ---
  async fetchCategories(): Promise<string[]> {
    const categories = getFromStorage<string[]>(VAULT_CATEGORIES_KEY, DEFAULT_CATEGORIES);
    return simulateApiCall(categories);
  },

  async saveCategories(categories: string[]): Promise<string[]> {
    saveToStorage(VAULT_CATEGORIES_KEY, categories);
    return simulateApiCall(categories);
  },

  // --- AI Safety ---
  async fetchSafetyKeywords(): Promise<string[]> {
    const keywords = getFromStorage<string[]>(SAFETY_KEYWORDS_KEY, DEFAULT_KEYWORDS);
    return simulateApiCall(keywords);
  },

  async saveSafetyKeywords(keywords: string[]): Promise<string[]> {
    saveToStorage(SAFETY_KEYWORDS_KEY, keywords);
    return simulateApiCall(keywords);
  },
  
  async fetchFlaggedPrompts(): Promise<FlaggedPrompt[]> {
    const prompts = getFromStorage<FlaggedPrompt[]>(FLAGGED_PROMPTS_KEY, []);
    return simulateApiCall(prompts);
  },
  
  async logFlaggedPrompt(promptData: FlaggedPrompt): Promise<FlaggedPrompt> {
    const prompts = getFromStorage<FlaggedPrompt[]>(FLAGGED_PROMPTS_KEY, []);
    prompts.push(promptData);
    saveToStorage(FLAGGED_PROMPTS_KEY, prompts);
    return simulateApiCall(promptData);
  },

  // --- User Profile ---
  async fetchUserProfile(): Promise<UserProfile | null> {
    const profile = getFromStorage<UserProfile | null>(USER_PROFILE_KEY, null);
    return simulateApiCall(profile);
  },

  async saveUserProfile(profile: UserProfile): Promise<UserProfile> {
    saveToStorage(USER_PROFILE_KEY, profile);
    return simulateApiCall(profile);
  },
};