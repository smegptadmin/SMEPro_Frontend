# SMEPro Lite Frontend

SMEPro Lite is a sophisticated, narrowly-trained subject matter expert (SME) AI Model built with React, TypeScript, and Tailwind CSS, powered by the Google Gemini API. It moves beyond generic chatbots by providing a structured, actionable, and collaborative environment where users can engage with specialized AI experts to solve complex problems.

## Key Features

### Core AI Interaction
- **Specialized AI Experts**: Select from a deep hierarchy of industries and organizational roles to engage an AI trained on your specific context.
- **Multi-SME Collaborative Workspaces**: Dynamically add multiple, different AI experts into a single chat session, creating a "workshop" environment for solving multi-faceted problems.
- **Guided Sessions & Action Plans**: The AI can generate interactive, step-by-step project plans directly in the chat, allowing users to track their progress and receive contextual guidance.
- **Verified Sources Mode**: For research-intensive tasks, the AI can ground its responses using Google Search, providing answers with verifiable citations.

### Knowledge Management
- **SMEPro Vault**: A persistent, personal knowledge base to save key insights, conversations, and generated plans.
- **Vault Search**: Quickly find saved items with a keyword search that scans content, titles, and SME context.
- **AI-Powered Vault Analysis**: The "Analysis Workbench" uses AI to read, analyze, and synthesize new strategies from the user's curated knowledge in the Vault.
- **SMEPro Builder**: Launch a document-generation tool directly from an AI analysis, turning a key insight into a structured project plan, strategy document, or email.
- **Universal API Connectors**: Integrate existing AI workflows by syncing conversation histories from OpenAI (ChatGPT), Grok, AWS Bedrock, and Google Gemini. SMEPro's AI automatically normalizes this external data into the structured, actionable format of the Vault.

### User Experience & Collaboration
- **Real-time Collaboration**: Share any chat session with a unique link, allowing team members to join and contribute in real-time.
- **Interactive Prompts & Suggestions**: The UI presents AI-generated follow-up questions as clickable buttons, and the AI can proactively suggest adding a more relevant SME to the conversation.
- **Rich Markdown Rendering**: Responses are beautifully formatted with code block syntax highlighting, copy buttons, and scrollable tables.
- **Full Marketing Site & Onboarding**: A multi-page marketing website (Home, Features, How It Works, Plans) guides new users through the product's value proposition.

### Administration & Safety
- **User Dashboard**: Visualize usage statistics, including session counts and Vault activity by category.
- **AI Safety Module**: A configurable safety layer to monitor user prompts for sensitive keywords, log flagged attempts, and provide warnings, ensuring responsible AI usage.

## Tech Stack

- **Frontend**: React, TypeScript, Tailwind CSS
- **AI Engine**: Google Gemini API (`@google/genai`)
- **Markdown Rendering**: `marked` & `highlight.js`
- **Backend Service**: Connects to a serverless backend (e.g., Google Cloud Run) for data persistence.

## Project Architecture

`App.tsx` serves as the central orchestrator, managing application state and routing between different views:
- **Marketing Site**: A set of components for public-facing pages (`HomePage`, `FeaturesPage`, etc.).
- **Main Application**:
  - `Sidebar`: Manages and displays a list of all user sessions.
  - `ChatWindow`: The core interface for interacting with the AI SMEs.
  - `Vault`: The user's knowledge base and analysis workbench.
  - `Dashboard`: Displays user analytics and safety settings.
- **Modals**: A suite of modal components handle discrete user actions like adding an SME, editing a profile, or saving an insight to the Vault.

## Backend Integration

This frontend is designed to work with a corresponding backend service for data persistence. The connection is configured in `src/services/backend.ts`, which points to a deployed backend URL (e.g., a Google Cloud Run service). This service handles:
- User Profiles
- Vault Items & Categories
- AI Safety Keywords & Logs

## Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) (v18 or newer recommended)
- [npm](https://www.npmjs.com/) (usually comes with Node.js)

### Installation

1.  **Clone the repository:**
    ```bash
    git clone <repository-url>
    cd smepro-lite
    ```

2.  **Install NPM packages:**
    ```bash
    npm install
    ```

### Configuration

The application requires a Google Gemini API key. The project reads this key from `process.env.API_KEY`. For local development with a tool like Vite, create a `.env.local` file in the project root:

```
VITE_API_KEY=YOUR_GEMINI_API_KEY_HERE
```
*Note: The `VITE_` prefix is important if you are using Vite.*

### Running the Application

This project is a standard React application and requires a development server to run.

```bash
# Example using Vite (if you have it installed globally)
npm install -g vite
vite
```
This will start the app, typically at `http://localhost:5173`.

## Deployment

SMEPro Lite is built as a **static single-page application (SPA)**. To deploy, you first build the project, which compiles all the React/TypeScript code into a set of static HTML, CSS, and JavaScript files.

```bash
# Example using Vite
vite build
```

The output in the `dist/` directory can then be hosted on any static hosting provider like Vercel, Netlify, AWS S3, or Firebase Hosting.

## Note on Dependencies

This is a JavaScript/TypeScript project. Its dependencies are managed by the `package.json` file. The `requirements.txt` file is included for high-level informational purposes only and is not used by the build system. For a definitive list of project dependencies, please refer to `package.json`.