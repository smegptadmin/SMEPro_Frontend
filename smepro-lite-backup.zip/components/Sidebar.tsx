import React, { useState, useEffect, useMemo } from 'react';
import { ChatSession, VaultItem } from '../types';
import { collaborationService } from '../services/collaboration_service';
import { backend } from '../services/backend';

interface SidebarProps {
  isOpen: boolean;
  currentSessionId: string | null;
  onSelectSession: (sessionId: string) => void;
  onNewChat: () => void;
  onDeleteSession: (sessionId: string) => void;
}

const RETENTION_POLICY_KEY = 'smeProRetentionPolicy';

const Sidebar: React.FC<SidebarProps> = ({ isOpen, currentSessionId, onSelectSession, onNewChat, onDeleteSession }) => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [vaultItems, setVaultItems] = useState<VaultItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [deletingSessionId, setDeletingSessionId] = useState<string | null>(null);
  const [showArchived, setShowArchived] = useState(false);
  const [retentionPolicy, setRetentionPolicy] = useState<string>(() => {
    return localStorage.getItem(RETENTION_POLICY_KEY) || 'forever';
  });

  const fetchData = async () => {
      const [allSessions, allVaultItems] = await Promise.all([
        collaborationService.getAllSessions(),
        backend.fetchVaultItems()
      ]);
      setSessions(allSessions);
      setVaultItems(allVaultItems);
  };

  useEffect(() => {
    fetchData();
  }, [currentSessionId]);

  useEffect(() => {
    localStorage.setItem(RETENTION_POLICY_KEY, retentionPolicy);

    const applyRetentionPolicy = async () => {
        if (retentionPolicy === 'forever') return;

        const allSessions = await collaborationService.getAllSessions();
        const now = Date.now();
        const days = parseInt(retentionPolicy.replace(/[a-zA-Z]/g, ''), 10);
        if (isNaN(days)) return;

        const cutoff = now - days * 24 * 60 * 60 * 1000;

        if (retentionPolicy.startsWith('delete')) {
            const sessionsToDelete = allSessions.filter(session => session.lastModified < cutoff);
            if (sessionsToDelete.length > 0) {
                for (const session of sessionsToDelete) {
                    await collaborationService.deleteSession(session.sessionId);
                }
            }
        } else { // Archive policy
            const sessionsToArchive = allSessions.filter(
                session => session.lastModified < cutoff && session.status !== 'archived'
            );
            if (sessionsToArchive.length > 0) {
                const updates = sessionsToArchive.map(s => ({ sessionId: s.sessionId, status: 'archived' as const }));
                await collaborationService.batchUpdateSessionStatus(updates);
            }
        }
        
        // Refresh the list after applying the policy
        if (retentionPolicy !== 'forever') {
            fetchData();
        }
    };

    applyRetentionPolicy();
  }, [retentionPolicy]);

  const handleUnarchive = async (sessionId: string) => {
    await collaborationService.updateSessionStatus(sessionId, 'active');
    fetchData(); // Refetch to update the list
  };

  const sessionTree = useMemo(() => {
    const vaultItemsBySessionId = new Map<string, VaultItem[]>();
    vaultItems.forEach(item => {
        if (item.sourceSessionId) {
            if (!vaultItemsBySessionId.has(item.sourceSessionId)) {
                vaultItemsBySessionId.set(item.sourceSessionId, []);
            }
            vaultItemsBySessionId.get(item.sourceSessionId)!.push(item);
        }
    });

    vaultItemsBySessionId.forEach((items) => {
        items.sort((a, b) => a.savedAt - b.savedAt);
    });

    const visibleSessions = sessions.filter(session => {
        if (showArchived) return true;
        return session.status === 'active' || !session.status;
    });

    const searchedSessions = visibleSessions.filter(session => {
        if (!searchQuery.trim()) return true;
        const lowerCaseQuery = searchQuery.toLowerCase();

        const titleMatch = session.title?.toLowerCase().includes(lowerCaseQuery);
        const smeMatch = session.smeConfigs.some(sme => 
            sme.industry.toLowerCase().includes(lowerCaseQuery) ||
            sme.subType.toLowerCase().includes(lowerCaseQuery) ||
            sme.segment.toLowerCase().includes(lowerCaseQuery)
        );

        return titleMatch || smeMatch;
    });


    return searchedSessions.map(session => ({
        ...session,
        vaultChildren: vaultItemsBySessionId.get(session.sessionId) || []
    }));
  }, [sessions, vaultItems, showArchived, searchQuery]);
  
  const handleConfirmDelete = async () => {
    if (deletingSessionId) {
      await collaborationService.deleteSession(deletingSessionId);
      onDeleteSession(deletingSessionId);
      setSessions(sessions.filter(s => s.sessionId !== deletingSessionId));
      setDeletingSessionId(null);
    }
  };


  return (
    <aside className={`flex-shrink-0 bg-slate-900/50 border-r border-slate-700 flex flex-col p-3 transition-all duration-300 ${isOpen ? 'w-64' : 'w-0 p-0 overflow-hidden'}`}>
      <button
        onClick={onNewChat}
        className="w-full flex items-center justify-between text-left p-2.5 mb-2 bg-slate-700 hover:bg-slate-600 rounded-lg border border-slate-600 transition-colors text-white font-semibold text-sm"
      >
        New Chat
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4"><path d="M8.75 3.75a.75.75 0 0 0-1.5 0v3.5h-3.5a.75.75 0 0 0 0 1.5h3.5v3.5a.75.75 0 0 0 1.5 0v-3.5h3.5a.75.75 0 0 0 0-1.5h-3.5v-3.5Z" /></svg>
      </button>

      <div className="relative mb-3 flex-shrink-0">
          <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search sessions..."
              className="w-full p-2 pl-8 bg-slate-700 border border-slate-600 rounded-lg text-sm text-white placeholder:text-slate-500 focus:ring-2 focus:ring-cyan-500 outline-none"
          />
          <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 3.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11ZM2 9a7 7 0 1 1 12.452 4.391l3.328 3.329a.75.75 0 1 1-1.06 1.06l-3.329-3.328A7 7 0 0 1 2 9Z" clipRule="evenodd" /></svg>
      </div>

      <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-2 mb-2">
        {showArchived ? 'Archived Sessions' : 'Recent Sessions'}
      </h2>
      <nav className="flex-grow overflow-y-auto -mr-1 pr-1">
        {sessionTree.map(session => (
            <div key={session.sessionId} className={`space-y-1 py-1 ${session.status === 'archived' ? 'opacity-60' : ''}`}>
                <div className="group flex items-center justify-between">
                  <button
                    onClick={() => onSelectSession(session.sessionId)}
                    className={`flex-grow text-left p-2 rounded-md text-sm truncate transition-colors ${
                      session.sessionId === currentSessionId
                        ? 'bg-cyan-900/50 text-white font-semibold'
                        : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                    }`}
                    title={session.title || session.smeConfigs[0]?.segment}
                  >
                    {session.title || session.smeConfigs[0]?.segment}
                  </button>
                  
                  {session.status === 'archived' ? (
                      <button onClick={() => handleUnarchive(session.sessionId)} className="p-1 text-slate-400 hover:text-cyan-400 transition-opacity flex-shrink-0 ml-1" title="Unarchive">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4"><path d="M3.5 3A1.5 1.5 0 0 0 2 4.5v2.75a.75.75 0 0 0 1.5 0V5h10v2.25a.75.75 0 0 0 1.5 0V4.5A1.5 1.5 0 0 0 13.5 3h-10Z" /><path d="M11.5 8.25a.75.75 0 0 1 .75.75v3.19l1.47-1.47a.75.75 0 0 1 1.06 1.06l-2.75 2.75a.75.75 0 0 1-1.06 0L8 11.78a.75.75 0 0 1 1.06-1.06l1.44 1.44V9a.75.75 0 0 1 .75-.75Z" /></svg>
                      </button>
                  ) : (
                      deletingSessionId === session.sessionId ? (
                        <div className="flex items-center flex-shrink-0 ml-1">
                            <button onClick={handleConfirmDelete} className="text-xs text-red-400 hover:underline">Delete?</button>
                            <span className="text-slate-600 mx-1">/</span>
                            <button onClick={() => setDeletingSessionId(null)} className="text-xs text-slate-400 hover:underline">No</button>
                        </div>
                      ) : (
                        <button onClick={() => setDeletingSessionId(session.sessionId)} className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-red-400 transition-opacity flex-shrink-0">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4"><path fillRule="evenodd" d="M5 3.25V4H2.75a.75.75 0 0 0 0 1.5h.3l.815 8.15A1.5 1.5 0 0 0 5.357 15h5.285a1.5 1.5 0 0 0 1.493-1.35l.815-8.15h.3a.75.75 0 0 0 0-1.5H11v-.75A2.25 2.25 0 0 0 8.75 1h-1.5A2.25 2.25 0 0 0 5 3.25Zm2.25-.75a.75.75 0 0 0-.75.75V4h3v-.75a.75.75 0 0 0-.75-.75h-1.5ZM6.05 6a.75.75 0 0 1 .787.71l.5 5a.75.75 0 1 1-1.474.14l-.5-5A.75.75 0 0 1 6.05 6Zm3.9 0a.75.75 0 0 1 .71.787l-.5 5a.75.75 0 1 1-1.474-.14l.5-5a.75.75 0 0 1 .764-.647Z" clipRule="evenodd" /></svg>
                        </button>
                      )
                  )}
                </div>
                {session.vaultChildren.length > 0 && (
                    <div className="pl-4 pt-1 pb-1 border-l-2 border-slate-700 ml-2">
                        <div className="space-y-1">
                            {session.vaultChildren.map(item => (
                                <div key={item.id} className="flex items-center gap-2 p-1.5 rounded-md text-slate-400 hover:bg-slate-700/50 cursor-default" title={`Saved: ${item.smeConfig.segment}`}>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4 text-slate-500 flex-shrink-0"><path d="M3.75 2h8.5A1.75 1.75 0 0 1 14 3.75v9.5a.75.75 0 0 1-1.21.62L7.5 10.632 2.21 13.87a.75.75 0 0 1-1.21-.62V3.75C1 2.784 1.784 2 2.75 2H3c.414 0 .75.336.75.75v10.53l3.75-2.25 3.75 2.25V2.75a.75.75 0 0 0-.75-.75h-.5Z" /></svg>
                                    <span className="text-xs truncate">
                                        {item.smeConfig.segment}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        ))}
        {sessionTree.length === 0 && (
            <p className="text-xs text-slate-500 text-center px-2 py-4">{searchQuery ? `No sessions found for "${searchQuery}".` : 'No recent sessions found.'}</p>
        )}
      </nav>
      <footer className="flex-shrink-0 mt-auto pt-3 border-t border-slate-700 space-y-2">
        <div>
          <label htmlFor="retention-policy" className="text-xs font-medium text-slate-400">Session Policy:</label>
          <select
            id="retention-policy"
            value={retentionPolicy}
            onChange={(e) => setRetentionPolicy(e.target.value)}
            className="w-full mt-1 bg-slate-700 border-slate-600 rounded-md p-1.5 text-xs text-white focus:ring-2 focus:ring-cyan-500 outline-none"
          >
            <option value="forever">Keep Forever</option>
            <option value="30d">Archive after 30 Days</option>
            <option value="90d">Archive after 90 Days</option>
            <option value="delete90d">Delete after 90 Days</option>
          </select>
        </div>
        <button onClick={() => setShowArchived(!showArchived)} className="w-full text-center text-xs text-cyan-400 hover:underline">
          {showArchived ? 'Hide Archived' : 'Show Archived'}
        </button>
      </footer>
    </aside>
  );
};

export default Sidebar;